package com.example.troisapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class InterfaceStaff extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interface_staff);
    }
}